ИНСТРУКЦИЯ ПО ЗАПУСКУ
1.ОТКРОЙТЕ БАТНИК ОТ ИМЕНИ АДМЕНИСТРАТОРА
2.ЗАЙДИТЕ В КОРНЕВУЮ ПАПКУ ИГРЫ (ПРИМЕР C:\Program Files (x86)\Steam\steamapps\common\Game\game.exe) БЕЗ СКОБОК!!
3.НАЖМИТЕ ENTER
4.ДОЖДИТЕСЬ ЗАГРУЗКИ
5.ИГРАЙТЕ
ПРИМЕЧАНИЕ!!
1.С ИГРЫ МОГУТ СЛИТЕТЬ СОХРАНЕНИЯ
2.ДЛЯ ЗАПУСКА НУЖНО ЗАПУСТИТЬ КЛИЕНТ СТИМ
3.В КОНСОЛИ МОГУТ БЫТЬ ОШИБКИ ПОЧТИ ВСЕГДА ОНИ ФЕЙКОВЫЕ
ЭТОТ СКРИПТ СОЗДАН В ОБРАЗОВАТЕЛЬНЫХ ЦЕЛЯХ И ЕГО КАЖДЫЙ МОЖЕТ РЕДАКТИРОВАТЬ ЕГО САМ(В КОДЕ ЕСТЬ ПОДСКАЗКИ) ИСПОЛЬЗУЙТЕ ЕГО НА СВОЙ СТРАХ И РИСК!

en:

LAUNCH INSTRUCTIONS
1. OPEN THE BAT FILE AS AN ADMINISTRATOR
2. GO TO THE GAME'S ROOT FOLDER (EXAMPLE C:\Program Files (x86)\Steam\steamapps\common\Game\game.exe) WITHOUT PARENTHESES!!
3. PRESS ENTER
4. WAIT FOR THE LOADING
5. PLAY
NOTE!!
1.SAVINGS CAN BE LOST FROM THE GAME
2.TO LAUNCH YOU NEED TO LAUNCH THE STEAM CLIENT
3.THERE MAY BE ERRORS IN THE CONSOLE, THEY ARE ALMOST ALWAYS FAKE
THIS SCREEN WAS CREATED FOR EDUCATIONAL PURPOSES AND EVERYONE CAN EDIT IT ON THEIR OWN(THERE ARE HINTS IN THE CODE) USE IT AT YOUR OWN RISK!