@echo off
chcp 65001 >nul
title SteamObxodik V1.2 By BALADOL
color 0
setlocal enabledelayedexpansion

:: ============================================
::         ADMIN RIGHTS CHECK
:: ============================================
:CHECK_ADMIN
net session >nul 2>&1
if %errorLevel% neq 0 (
    cls
    echo ================================================
    echo              ADMIN RIGHTS REQUIRED
    echo ================================================
    echo.
    color 0C
    echo ERROR: This script requires administrator privileges!
    color 0
    echo.
    echo Please restart the script as administrator
    echo.
    echo Press any key to try again...
    pause >nul
    goto CHECK_ADMIN
)

:: ============================================
::         MAIN MENU
:: ============================================
:MENU
cls
color 0
echo ================================================
echo              SteamObxodik V1.2
echo               License Bypass
echo ================================================
echo.
echo [1] Add API key to a single game
echo [2] Add API keys to ALL Steam games
echo [3] Delete API keys
echo [4] Exit
echo.
set /p "menu_choice=Select option (1-4): "

if "%menu_choice%"=="1" goto ADD_KEY
if "%menu_choice%"=="2" goto ADD_ALL_KEYS
if "%menu_choice%"=="3" goto DELETE_MENU
if "%menu_choice%"=="4" exit /b
goto MENU

:: ============================================
::         DELETE MENU
:: ============================================
:DELETE_MENU
cls
echo ================================================
echo               DELETE API KEYS
echo ================================================
echo.
echo [1] Delete ALL API keys from Steam common folder
echo [2] Delete API key from a single game
echo [3] Back to main menu
echo.
set /p "delete_choice=Select option (1-3): "

if "%delete_choice%"=="1" goto DELETE_ALL
if "%delete_choice%"=="2" goto DELETE_SINGLE
if "%delete_choice%"=="3" goto MENU
goto DELETE_MENU

:: ============================================
::         DELETE ALL API KEYS
:: ============================================
:DELETE_ALL
cls
echo ================================================
echo         DELETE ALL API KEYS FROM STEAM
echo ================================================
echo.
echo WARNING: This will delete ALL steam_appid.txt
echo files from your Steam common folder.
echo.

:: Check common Steam paths
set "STEAM_PATH=C:\Program Files (x86)\Steam\steamapps\common"
if not exist "%STEAM_PATH%" (
    set "STEAM_PATH=C:\Program Files\Steam\steamapps\common"
)
if not exist "%STEAM_PATH%" (
    echo.
    echo Steam common folder not found!
    echo.
    pause
    goto DELETE_MENU
)

echo Steam path: %STEAM_PATH%
echo.
set /p "confirm=Are you sure you want to continue? (y/n): "

if /i not "!confirm!"=="y" goto DELETE_MENU

echo.
echo ================================================
echo         SCANNING FOR API KEYS...
echo ================================================
echo.

set "TOTAL_DELETED=0"

:: Loop through all folders in Steam common
for /d %%d in ("%STEAM_PATH%\*") do (
    set "GAME_FOLDER=%%d"
    set "GAME_NAME=%%~nd"
    
    if exist "!GAME_FOLDER!\steam_appid.txt" (
        del /q "!GAME_FOLDER!\steam_appid.txt" 2>nul
        if not exist "!GAME_FOLDER!\steam_appid.txt" (
            echo [DELETED] !GAME_NAME! - steam_appid.txt
            set /a TOTAL_DELETED+=1
        )
    )
)

echo.
echo ================================================
echo         DELETE OPERATION COMPLETE
echo ================================================
echo.
echo Total files deleted: %TOTAL_DELETED%
echo.
pause
goto DELETE_MENU

:: ============================================
::         DELETE SINGLE API KEY
:: ============================================
:DELETE_SINGLE
cls
echo ================================================
echo         DELETE API KEY FROM A SINGLE GAME
echo ================================================
echo.
echo INSERT THE FULL PATH TO THE GAME'S EXE FILE
echo.
echo Example: C:\Program Files (x86)\Steam\steamapps\common\Game\game.exe
echo.
set /p "GAME_PATH=PATH: "

if "%GAME_PATH%"=="" goto DELETE_SINGLE
if not exist "%GAME_PATH%" (
    echo.
    echo File not found at the specified path!
    pause
    goto DELETE_SINGLE
)

:: GET GAME FOLDER (the folder containing the exe)
for %%F in ("%GAME_PATH%") do set "GAME_DIR=%%~dpF"
set "GAME_DIR=%GAME_DIR:~0,-1%"
set "GAME_NAME=%%~nF"

echo.
echo Game folder: %GAME_DIR%
echo.
echo Searching for API key files...
echo.

set "FILES_DELETED=0"

:: Check for steam_appid.txt
if exist "%GAME_DIR%\steam_appid.txt" (
    del /q "%GAME_DIR%\steam_appid.txt" 2>nul
    if not exist "%GAME_DIR%\steam_appid.txt" (
        echo [DELETED] steam_appid.txt
        set /a FILES_DELETED+=1
    )
) else (
    echo [NOT FOUND] steam_appid.txt
)

echo.
echo ================================================
echo         DELETE OPERATION COMPLETE
echo ================================================
echo.
echo Files deleted: %FILES_DELETED%
echo.
pause
goto DELETE_MENU

:: ============================================
::         OPTION 1 - ADD API KEY (SINGLE)
:: ============================================
:ADD_KEY
cls
echo ================================================
echo         ADD API KEY TO A SINGLE GAME
echo ================================================
echo.
echo INSERT THE FULL PATH TO THE GAME'S EXE FILE
echo.
echo Example: C:\Program Files (x86)\Steam\steamapps\common\Game\game.exe
echo.
set /p "GAME_PATH=PATH: "

if "%GAME_PATH%"=="" goto ADD_KEY
if not exist "%GAME_PATH%" (
    echo.
    echo File not found at the specified path!
    pause
    goto ADD_KEY
)

:: GET GAME FOLDER (the folder containing the exe)
for %%F in ("%GAME_PATH%") do set "GAME_DIR=%%~dpF"
set "GAME_DIR=%GAME_DIR:~0,-1%"
set "GAME_EXE=%%~nxF"
set "GAME_NAME=%%~nF"

echo.
echo Game folder: %GAME_DIR%
echo.

:: SELECT APP ID MENU
echo ================================================
echo            SELECT APP ID
echo ================================================
echo.
echo [1] 480 - Default (Spacewar)
echo [2] 600 - Default (Spacewar - alt)
echo.
set /p "app_choice=Select option (1-2): "

if "%app_choice%"=="1" set "APP_ID=480"
if "%app_choice%"=="2" set "APP_ID=600"
if "%APP_ID%"=="" goto ADD_KEY

echo Selected AppID: %APP_ID%

:: CHECK IF API KEY ALREADY EXISTS
if exist "%GAME_DIR%\steam_appid.txt" (
    echo.
    echo API key already exists in this folder
    type "%GAME_DIR%\steam_appid.txt"
    echo.
    echo [1] Overwrite with new key (%APP_ID%)
    echo [2] Keep existing key
    set /p "overwrite=Select option (1-2): "
    if "!overwrite!"=="2" (
        echo Keeping existing key...
        pause
        goto MENU
    )
)

:: CREATE ONLY THE steam_appid.txt FILE
echo %APP_ID% > "%GAME_DIR%\steam_appid.txt" 2>nul

:: VERIFY CREATION
if exist "%GAME_DIR%\steam_appid.txt" (
    echo.
    echo ================================================
    echo         API KEY ADDED SUCCESSFULLY
    echo ================================================
    echo.
    echo    AppID: %APP_ID%
    echo    File: %GAME_DIR%\steam_appid.txt
    echo.
    echo    Your saves are NOT affected
    echo.
    echo ================================================
    echo.
    echo [1] Launch the game now
    echo [2] Return to main menu
    echo.
    set /p "launch_choice=Select option (1-2): "
    
    if "!launch_choice!"=="1" (
        echo.
        echo Launching %GAME_NAME%...
        cd /d "%GAME_DIR%"
        start "" "%GAME_EXE%"
        echo.
        echo Game launched!
        echo.
        pause
    )
) else (
    echo.
    echo ================================================
    echo         FAILED TO CREATE API KEY
    echo ================================================
    echo.
    echo    Try running as administrator
    echo.
    pause
)

goto MENU

:: ============================================
::    OPTION 2 - ADD API KEYS TO ALL STEAM GAMES
:: ============================================
:ADD_ALL_KEYS
cls
echo ================================================
echo      ADD API KEYS TO ALL STEAM GAMES
echo ================================================
echo.
echo This will scan your Steam common folder and add
echo API keys to ALL games that don't already have one.
echo.
echo Existing keys will be SKIPPED (not modified).
echo.

:: Check common Steam paths
set "STEAM_PATH=C:\Program Files (x86)\Steam\steamapps\common"
if not exist "%STEAM_PATH%" (
    set "STEAM_PATH=C:\Program Files\Steam\steamapps\common"
)
if not exist "%STEAM_PATH%" (
    echo.
    echo Steam common folder not found!
    echo.
    pause
    goto MENU
)

echo Steam path: %STEAM_PATH%
echo.

:: SELECT DEFAULT APP ID FOR BULK OPERATION
echo ================================================
echo       SELECT DEFAULT APP ID FOR ALL GAMES
echo ================================================
echo.
echo [1] 480 - Default (Spacewar)
echo [2] 600 - Default (Spacewar - alt)
echo.
set /p "bulk_app_choice=Select option (1-2): "

if "%bulk_app_choice%"=="1" set "BULK_APP_ID=480"
if "%bulk_app_choice%"=="2" set "BULK_APP_ID=600"
if "%BULK_APP_ID%"=="" goto ADD_ALL_KEYS

echo.
echo Using AppID: %BULK_APP_ID% for all games
echo.
echo [1] Start scanning
echo [2] Back to menu
echo.
set /p "scan_choice=Select option (1-2): "

if "%scan_choice%"=="2" goto MENU
if not "%scan_choice%"=="1" goto ADD_ALL_KEYS

echo.
echo ================================================
echo                   SCANNING...
echo ================================================
echo.

set "TOTAL_FOLDERS=0"
set "GAMES_FOUND=0"
set "KEYS_ADDED=0"
set "KEYS_SKIPPED=0"
set "FAILED=0"

:: Loop through all folders in Steam common
for /d %%d in ("%STEAM_PATH%\*") do (
    set /a TOTAL_FOLDERS+=1
    set "GAME_FOLDER=%%d"
    set "GAME_NAME=%%~nd"
    
    :: Look for ANY .exe file in the game folder
    set "EXE_FOUND=0"
    for %%e in ("!GAME_FOLDER!\*.exe") do (
        if exist "%%e" set "EXE_FOUND=1"
    )
    
    if !EXE_FOUND! equ 1 (
        set /a GAMES_FOUND+=1
        echo [FOUND] !GAME_NAME!
        echo    Using AppID: %BULK_APP_ID%
        
        :: Check if key already exists
        if exist "!GAME_FOLDER!\steam_appid.txt" (
            echo     Key already exists - skipping
            set /a KEYS_SKIPPED+=1
        ) else (
            :: Create the key
            echo %BULK_APP_ID% > "!GAME_FOLDER!\steam_appid.txt" 2>nul
            if exist "!GAME_FOLDER!\steam_appid.txt" (
                echo     Key added successfully
                set /a KEYS_ADDED+=1
            ) else (
                echo     Failed to create key
                set /a FAILED+=1
            )
        )
        echo.
    )
)

echo ================================================
echo         SCANNING COMPLETE
echo ================================================
echo.
echo Total folders scanned: %TOTAL_FOLDERS%
echo Games found: %GAMES_FOUND%
echo.
echo Keys added: %KEYS_ADDED%
echo Keys skipped (already existed): %KEYS_SKIPPED%
echo Failed: %FAILED%
echo.
echo ================================================
echo.
pause
goto MENU